"""Line geometry helpers."""
